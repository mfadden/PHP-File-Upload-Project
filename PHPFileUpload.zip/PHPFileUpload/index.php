<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<form action="upload.php" method="POST" enctype="multipart/form-data">
   <input type="file" name="file">
    <button type="submit" name="submit">UPLOAD</button>
</form>
</body>
</html>